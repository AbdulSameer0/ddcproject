-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2024 at 12:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ddcproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `id` int(100) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '123456', '2024-11-14 10:42:22');

-- --------------------------------------------------------

--
-- Table structure for table `programme_info`
--

CREATE TABLE `programme_info` (
  `prog_id` int(200) NOT NULL,
  `progTitle` varchar(200) NOT NULL,
  `targetGroup` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `progDirector` varchar(200) NOT NULL,
  `dealingAsstt` varchar(200) NOT NULL,
  `progPdf` longblob NOT NULL,
  `attandancePdf` longblob NOT NULL,
  `materialLink` varchar(200) NOT NULL,
  `paymentdone` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `programme_info`
--

INSERT INTO `programme_info` (`prog_id`, `progTitle`, `targetGroup`, `date`, `progDirector`, `dealingAsstt`, `progPdf`, `attandancePdf`, `materialLink`, `paymentdone`, `created_at`) VALUES
(45, 'demo', 'demo', '2024-11-16', 'demo', 'da1', 0x50444647616c6c6572795f32303234303832305f3135343732352e706466, 0x70726f6772616d6d655f696e666f2d70726f675064665f312e62696e, 'demo', 'yes', '2024-11-16 12:51:05'),
(55, 'demo1', 'demo1', '2024-11-18', 'demo1', 'da1', 0x70726f6772616d6d655f696e666f2d70726f67506466202832295f312e62696e, 0x70726f6772616d6d655f696e666f2d70726f675064665f322e62696e, 'demo1', 'yes', '2024-11-16 15:35:42'),
(56, 'demo2', 'demo2', '2024-11-19', 'demo2', 'da3', 0x50444647616c6c6572795f32303234303832305f3135343732362e706466, 0x50444647616c6c6572795f32303234303832305f3135343732342e706466, 'demo2', 'yes', '2024-11-16 15:37:29'),
(57, 'demo3', 'demo3', '2024-11-28', 'demo3', 'da2', 0x70726f6772616d6d655f696e666f2d70726f675064662e62696e, 0x70726f6772616d6d655f696e666f2d70726f675064665f332e62696e, 'demo3', 'no', '2024-11-16 15:39:34'),
(61, 'dsad', 'safsaf', '2024-11-22', 'sfsf', 'da1', 0x4d61795f323032342e706466, 0x417072696c5f323032352e706466, 'sfsfsf', 'yes', '2024-11-16 16:23:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programme_info`
--
ALTER TABLE `programme_info`
  ADD PRIMARY KEY (`prog_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `programme_info`
--
ALTER TABLE `programme_info`
  MODIFY `prog_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
